import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useMemo,
} from "react";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
} from "firebase/auth";
import { doc, getDoc, setDoc, updateDoc } from "firebase/firestore";
import { auth, db } from "../firebase/config";
import { logUserLogin, logUserLogout } from "../utils/auditTracker";

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState(null);
  // Track if this is a direct login (not a refresh or restoration)
  const [isDirectLogin, setIsDirectLogin] = useState(false);

  const fetchUserData = useCallback(async (user) => {
    if (!user) {
      setUserData(null);
      return;
    }

    try {
      const userDoc = await getDoc(doc(db, "users", user.uid));
      if (userDoc.exists()) {
        setUserData(userDoc.data());
      } else {
        // Create new user document if it doesn't exist
        const newUserData = {
          email: user.email,
          role: "user",
          createdAt: new Date().toISOString(),
          darkMode: window.matchMedia("(prefers-color-scheme: dark)").matches,
        };
        await setDoc(doc(db, "users", user.uid), newUserData);
        setUserData(newUserData);
      }
    } catch (error) {
      setUserData(null);
    }
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      await fetchUserData(user);
      setLoading(false);
    });

    return unsubscribe;
  }, [fetchUserData]);

  const login = useCallback(
    async (email, password) => {
      try {
        setLoading(true);
        setAuthError(null);
        // Set the direct login flag to indicate this is a real login, not a page refresh
        setIsDirectLogin(true);
        const userCredential = await signInWithEmailAndPassword(
          auth,
          email,
          password
        );
        await fetchUserData(userCredential.user);
        // Log the login event to audit trail - this is a real login with email/password
        await logUserLogin({
          uid: userCredential.user.uid,
          email: userCredential.user.email,
          role: userData?.role || "user",
        });
        return userCredential.user;
      } catch (error) {
        console.error("Login error:", error);
        setAuthError("Invalid email or password");
        setLoading(false);
        throw error;
      } finally {
        // Reset the direct login flag
        setIsDirectLogin(false);
      }
    },
    [fetchUserData, userData]
  );

  const register = useCallback(async (email, password, role, name) => {
    try {
      setLoading(true);
      setAuthError(null);
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        email,
        password
      );
      const newUserData = {
        email: userCredential.user.email,
        name: name,
        role: role,
        createdAt: new Date().toISOString(),
        darkMode: window.matchMedia("(prefers-color-scheme: dark)").matches,
      };
      await setDoc(doc(db, "users", userCredential.user.uid), newUserData);
      setUserData(newUserData);
      return userCredential.user;
    } catch (error) {
      console.error("Registration error:", error);
      setAuthError("Failed to register account");
      setLoading(false);
      throw error;
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      // Log the logout event to audit trail before signing out
      if (currentUser && userData) {
        // Only use the new logging method to avoid duplication
        await logUserLogout({
          uid: currentUser.uid,
          email: currentUser.email,
          role: userData.role || "user",
        });
      }

      setLoading(true);
      await signOut(auth);
      setUserData(null);
    } catch (error) {
      console.error("Logout error:", error);
      setAuthError("Failed to log out");
      setLoading(false);
      throw error;
    }
  }, [currentUser, userData]);

  const updateUserData = useCallback(
    async (updates) => {
      if (!currentUser) return;

      try {
        const userRef = doc(db, "users", currentUser.uid);
        await updateDoc(userRef, updates);
        setUserData((prev) => ({ ...prev, ...updates }));
      } catch (error) {
        console.error("Error updating user data:", error);
        throw error;
      }
    },
    [currentUser]
  );

  const value = useMemo(
    () => ({
      currentUser,
      userData,
      loading,
      authError,
      login,
      register,
      logout,
      updateUserData,
    }),
    [
      currentUser,
      userData,
      loading,
      authError,
      login,
      register,
      logout,
      updateUserData,
    ]
  );

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
